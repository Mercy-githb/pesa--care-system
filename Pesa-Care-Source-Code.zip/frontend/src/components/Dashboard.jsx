import React from 'react';

export default function Dashboard() {
  return (
    <div>
      <h2>Welcome to Pesa Care Dashboard</h2>
      <p>You are logged in!</p>
    </div>
  );
}