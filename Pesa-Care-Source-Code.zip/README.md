# Pesa Care – Digital Financial Management System

**Pesa Care** is a financial management platform built to promote financial inclusion for Kenyan youth and small entrepreneurs. It solves challenges around limited access to loans, poor financial literacy, and lack of digital tools for economic empowerment.

---

## 🧩 Features
- User registration and login
- Secure authentication using JWT
- Simple frontend with React
- Flask backend connected to MySQL
- API endpoints for login/register
- Ready for extension with savings, loans, investments, etc.

---

## 🛠️ Technologies Used
- **Frontend:** React, HTML, CSS, JavaScript
- **Backend:** Python (Flask)
- **Database:** MySQL
- **Other:** JWT, bcrypt, Flask-CORS, Axios

---

## 🧪 How to Run

### 1. Backend (Flask)
```bash
cd backend
pip install -r requirements.txt
python app.py
```

### 2. MySQL Setup
- Import the `db.sql` file into your MySQL server:
```sql
source db.sql;
```

### 3. Frontend (React)
```bash
cd frontend
npm install
npm start
```

---

## 🧑‍💻 Developer
**Mercy Wakaria Munene**  
Email: munenemercy2001@gmail.com  
Phone: +254 114 568 780

---

## 📌 Notes
- Be sure to start the backend first before running the frontend.
- Update CORS or API URLs if deploying online.