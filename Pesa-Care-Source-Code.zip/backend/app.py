from flask import Flask
from flask_cors import CORS
from config import init_mysql
from auth import register_routes

app = Flask(__name__)
CORS(app)
mysql = init_mysql(app)
register_routes(app, mysql)

if __name__ == '__main__':
    app.run(debug=True)