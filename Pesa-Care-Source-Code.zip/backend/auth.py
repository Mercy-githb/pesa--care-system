from flask import Blueprint, request, jsonify
from flask_bcrypt import Bcrypt
import jwt
import datetime

bcrypt = Bcrypt()
auth = Blueprint('auth', __name__)
SECRET_KEY = 'your_secret_key'

def create_token(user):
    payload = {
        'user_id': user['id'],
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def decode_token(token):
    return jwt.decode(token, SECRET_KEY, algorithms=['HS256'])

def register_routes(app, mysql):
    @auth.route('/register', methods=['POST'])
    def register():
        data = request.json
        name = data['name']
        email = data['email']
        password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
        role = data.get('role', 'user')

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(name, email, password, role) VALUES(%s, %s, %s, %s)", (name, email, password, role))
        mysql.connection.commit()
        return jsonify({'message': 'User registered successfully'}), 201

    @auth.route('/login', methods=['POST'])
    def login():
        data = request.json
        email = data['email']
        password = data['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cur.fetchone()

        if user and bcrypt.check_password_hash(user['password'], password):
            token = create_token(user)
            return jsonify({'token': token})
        else:
            return jsonify({'message': 'Invalid credentials'}), 401

    app.register_blueprint(auth)